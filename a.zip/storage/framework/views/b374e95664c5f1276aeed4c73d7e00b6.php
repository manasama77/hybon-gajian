<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex items-center justify-between">
            <h2 class="dark:text-gray-200 text-xl font-semibold leading-tight text-gray-800">
                <?php echo e(__('Data Slip Gaji')); ?>

            </h2>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="sm:px-6 lg:px-8 max-w-full mx-auto">

            <?php if($errors->any()): ?>
                <div class="dark:bg-red-700 dark:text-red-100 px-6 py-4 mb-4 text-red-700 bg-red-100 rounded-md">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="dark:text-red-100"><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="dark:bg-gray-800 sm:rounded-lg overflow-hidden bg-white shadow-sm">
                <div class="dark:text-gray-100 p-6 text-gray-900">

                    <div class="sm:rounded-lg relative overflow-x-auto shadow-md">
                        <table id="tables" class="dark:text-gray-400 w-full text-sm text-left text-gray-500">
                            <thead
                                class="bg-gray-50 dark:bg-gray-700 dark:text-gray-400 text-xs text-gray-700 uppercase">
                                <tr>
                                    <?php if(auth()->user()->hasRole('admin')): ?>
                                        <th scope="col" class="px-6 py-3">
                                            Karyawan
                                        </th>
                                    <?php endif; ?>
                                    <th scope="col" class="px-6 py-3">
                                        Periode
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Hadir
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Absen
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Cuti
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Sakit
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Ijin
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Terlambat
                                    </th>
                                    <th scope="col" class="px-6 py-3">
                                        Lembur
                                    </th>
                                    <th scope="col" class="px-6 py-3 text-center">
                                        <i class="fas fa-cog"></i>
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($slip_gajis->isEmpty()): ?>
                                    <tr
                                        class="dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 bg-white border-b">
                                        <th class="whitespace-nowrap dark:text-white px-6 py-4 font-medium text-center text-gray-900"
                                            colspan="10">
                                            Data tidak ditemukan
                                        </th>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $slip_gajis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slip_gaji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr
                                        class="dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600 bg-white border-b">
                                        <?php if(auth()->user()->hasRole('admin')): ?>
                                            <td class="px-6 py-4">
                                                <?php echo e($slip_gaji->karyawan->name); ?>

                                            </td>
                                        <?php endif; ?>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->periode_cutoff->kehadiran_start->format('d M Y')); ?> ~
                                            <?php echo e($slip_gaji->periode_cutoff->kehadiran_end->format('d M Y')); ?>

                                            (Kehadiran)
                                            <br />
                                            <?php echo e($slip_gaji->periode_cutoff->lembur_start->format('d M Y')); ?> ~
                                            <?php echo e($slip_gaji->periode_cutoff->lembur_end->format('d M Y')); ?> (Lembur)
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_hari_kerja); ?> Hari
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_hari_tidak_kerja); ?> Hari
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_cuti); ?> Hari
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_sakit); ?> Hari
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_hari_ijin); ?> Hari
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->menit_terlambat); ?> Menit
                                        </td>
                                        <td class="px-6 py-4">
                                            <?php echo e($slip_gaji->total_menit_lembur); ?> Menit
                                        </td>
                                        <td class="px-6 py-4 text-center">
                                            <a href="<?php echo e(route('slip-gaji.download', $slip_gaji)); ?>"
                                                class="text-white bg-blue-700 hover:bg-blue-800 focus:outline-none focus:ring-4 focus:ring-blue-300 font-medium rounded-full text-sm px-5 py-2.5 text-center me-2 mb-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800"
                                                target="_blank"><i class="fa-solid fa-file-arrow-down"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <div class="mt-4">
                        <?php echo e($slip_gajis->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php $__env->startPush('scripts'); ?>
        <script></script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\hybon-gajian\resources\views/pages/slip_gaji/index.blade.php ENDPATH**/ ?>