<table>
    <thead>
        <tr>
            <th>NAMA</th>
            <th>GAJI POKOK</th>
            <th>LEMBUR</th>
            <th>ABSENSI</th>
            <th>KETERLAMBATAN</th>
            <th>IJIN</th>
            <th>KASBON</th>
            <th>TAKE HOME PAY</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $recaps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recap): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($recap['nama_karyawan']); ?></td>
                <td><?php echo e($recap['gaji']); ?></td>
                <td><?php echo e($recap['lembur']); ?></td>
                <td><?php echo e($recap['absensi']); ?></td>
                <td><?php echo e($recap['keterlambatan']); ?></td>
                <td><?php echo e($recap['ijin']); ?></td>
                <td><?php echo e($recap['kasbon']); ?></td>
                <td><?php echo e($recap['take_home_pay']); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    <tfoot>
        <tr>
            <th colspan="7" align="right">Grand Total</th>
            <th><?php echo e($gt); ?></th>
        </tr>
    </tfoot>
</table>
<?php /**PATH C:\laragon\www\hybon-gajian\resources\views/excel/recap.blade.php ENDPATH**/ ?>