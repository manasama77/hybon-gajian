<img src="{{ asset('hybon-logo-circle.png') }}" {{ $attributes }} alt="Hybon Logo">
